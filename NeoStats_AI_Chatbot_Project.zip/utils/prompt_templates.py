CONCISE_PROMPT = "Answer briefly in 2–3 sentences. Cite sources if available."
DETAILED_PROMPT = "Provide a detailed, step-by-step explanation with examples and list sources."
